import math
a = -math.pi
b = math.pi
h = math.pi/6
while a<=b:
    y = a/2 * math.cos(a)-math.sin(a)
    print(y)
    a = a + h

import math
#повышенное
a = int(input())
b = int(input())
h = int(input())
k = 1
sum = 0
while a <= b:
    s = a math.factorial(k) (-1+k) 2k^2+
