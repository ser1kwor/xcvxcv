# first_number = int(input("Введите первое число "))
# second_number = int(input("Введите второе число "))
# znak = input("Введите знак операции ")
# y = 0
# if znak == "+" "-" "/" "*":
#     print("Знак операции верный")
# elif znak == "+":
#     y = first_number + second_number
#     print(y)
# elif znak == "-":
#     y = first_number - second_number
#     print(y)
# elif znak == "*":
#     y = first_number * second_number
#     print(y)
# elif znak == "/":
#     if second_number == 0:
#         print("На ноль делить нельзя")
#     y = first_number / second_number
#     print(y)
# else:
#     print("Знак операции неверный")

min_a = int(input())
max_a = int(input())
h = int(input())
print(min_a)
while min_a <= max_a:
    min_a = min_a + h
    if min_a >= max_a:
        break
    print(min_a)
